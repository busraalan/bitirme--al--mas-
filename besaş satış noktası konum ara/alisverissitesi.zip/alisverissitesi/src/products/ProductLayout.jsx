import React from 'react'
import Category from './Category'
import Products from './Products'

function ProductLayout() {
  return (
   <>
     <div className='row'>
     <div className='col-sm-8'>
       <Products/>
       </div>
       <div className='col-sm-4'>
        <Category/>

        </div>

      </div>
   </>
  )
}

export default ProductLayout
