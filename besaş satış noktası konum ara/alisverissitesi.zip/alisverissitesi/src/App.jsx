import { useState } from "react";
import Navbar from "./components/Navbar.jsx";
import SiteRoutes from "./SiteRoutes.jsx";

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Navbar />
      <div className='container'>
        <div className='col-sm-12'>
          <SiteRoutes count={count}/>
        </div>
      </div>
    </>
  );
}

export default App;
