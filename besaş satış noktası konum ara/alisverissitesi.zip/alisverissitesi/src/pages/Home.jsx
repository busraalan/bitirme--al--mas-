import { Products } from "../products"



function Home() {
  
  return (
    <>
    <h1>Ana Sayfa</h1>
    <Products/>
    
      
    </>
  )
}

export default Home
